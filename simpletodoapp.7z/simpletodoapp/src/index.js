import React,{Component} from 'react';
import ReactDOM from 'react-dom';
import TodoApp from './components/todo-components';
import store from './store';

// ReactDOM.render(<App />, document.getElementById('root'));
// import {combineReducers,createStore} from 'redux';


const render=()=>{
    ReactDOM.render(<TodoApp todos={store.getState()}  />,document.getElementById("root"));
};

store.subscribe(render);

render();










