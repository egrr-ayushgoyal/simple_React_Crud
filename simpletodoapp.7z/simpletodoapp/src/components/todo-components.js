import React,{Component} from 'react';
import store from '../store';
// var client = require('./client');


let nextTodoId=0;

class TodoApp extends Component{
     render (){
             return (
                 <div>
                         <input className="form-control" ref={ (node) => {this.inputTitle = node;} }  />
                         <input className="form-control" ref={ (node) => {this.inputDescription = node;} }  />

                         <button onClick={()=>{ store.dispatch({
                             id : nextTodoId++,
                             title : this.inputTitle.value,
                             description : this.inputDescription.value,
                             type : 'ADD_TODO'
                                 })
                                this.inputTitle.value='';
                                this.inputDescription.value='';
                            }}>
                            Add Todo
                         </button>
                     <ul>
                         {this.props.todos.map(todo => <Todo_Item key={todo.id} todo={todo} /> )}
                     </ul>
                 </div>

             );
     }
 }

 const Todo_Item = (props)=>(
     <li key={props.todo.id} >
         <b>Title </b>{props.todo.title}
         <b> Description </b>{props.todo.description}

     </li>
 );

export default TodoApp;
