import React from 'react';

const Home = React.createClass({
  render: function() {
    return (
      <div className="home-page">
        <h1>The app is now using Redux</h1>
        <p>
        Welcome to React-Redux Single Page App
        </p>
      </div>
    );
  }
});

export default Home;
